# Simple RAG (Retrieval-Augmented Generation) System

A self-contained, dependency-light RAG pipeline for question-answering over
your own PDFs/text files. Matches the architecture in the project brief:

```
Document Ingestion -> Text Chunking -> Embedding Creation -> Vector Database
    -> Query Processing -> Context Retrieval -> Answer Generation
```

## Files

- `rag_system.py` — the library: `DocumentLoader`, `TextChunker`, `VectorStore`,
  `AnswerGenerator`, and `RAGPipeline`.
- `demo.py` — a CLI you can run directly.
- `documents/` — drop your own PDFs/TXT/MD files here.

## Setup

```bash
pip install -r requirements.txt
```

## Run it

```bash
# Put your own files in ./documents, then:
python demo.py --docs documents --question "What is this document about?"

# Or go interactive:
python demo.py --docs documents
```

By default this runs in **extractive mode** — no API key needed. It retrieves
the most relevant passages and returns them directly as the "answer". This is
the retrieval half of RAG working end-to-end, which is enough to see and test
the whole pipeline immediately.

## Plugging in a real language model

To have an LLM actually *synthesize* an answer from the retrieved context
(rather than just returning the passages), switch backends:

```bash
export ANTHROPIC_API_KEY=your_key_here
python demo.py --docs documents --backend anthropic --question "..."

# or
export OPENAI_API_KEY=your_key_here
python demo.py --docs documents --backend openai --model gpt-4o-mini --question "..."
```

(`pip install anthropic` or `pip install openai` first — see the commented-out
lines in `requirements.txt`.)

## How each pipeline stage is implemented

| Stage | Implementation |
|---|---|
| 1. Document Ingestion | `DocumentLoader` — reads PDF (via `pypdf`) and plain text |
| 2. Text Chunking | `TextChunker` — overlapping word-based windows (configurable size/overlap) |
| 3. Embedding Creation | `VectorStore` — TF-IDF vectors via scikit-learn |
| 4. Vector Database | `VectorStore.matrix` — an in-memory sparse matrix, searched with cosine similarity |
| 5. Query Processing | `VectorStore.search()` — transforms the question into the same TF-IDF space |
| 6. Context Retrieval | top-k most similar chunks returned with their similarity scores |
| 7. Answer Generation | `AnswerGenerator` — extractive fallback, or Anthropic/OpenAI for real generation |

## Why TF-IDF instead of neural embeddings?

TF-IDF keeps the whole system runnable with no model downloads and no GPU —
good for getting the pipeline working end-to-end first. Once it's working,
the natural "Improvements & Experiments" upgrade (as called out in the brief)
is to swap `VectorStore`'s vectorizer for a neural embedding model, e.g.:

```python
from sentence_transformers import SentenceTransformer
model = SentenceTransformer("all-MiniLM-L6-v2")
vectors = model.encode(chunk_texts)
```

and swap `cosine_similarity` search for a proper vector index (FAISS, Chroma,
Pinecone, etc.) once your corpus gets large. The rest of the pipeline
(`RAGPipeline`, chunking, generation) doesn't need to change.

## Other extensions suggested in the brief

- **Hybrid search**: combine TF-IDF (keyword) with a neural embedding score
- **Re-ranking**: re-score the top-k results with a cross-encoder before
  passing them to the generator
- **Better chunking**: split on sentence/paragraph boundaries instead of a
  fixed word count
