"""
Simple Retrieval-Augmented Generation (RAG) System
====================================================

Implements the pipeline: Document Ingestion -> Chunking -> Embedding ->
Vector Store -> Query Processing -> Context Retrieval -> Answer Generation.

Design notes
------------
- Retrieval uses TF-IDF + cosine similarity (scikit-learn). This keeps the
  system fully self-contained and runnable offline, with no model weights
  to download. Swap `VectorStore` for a sentence-transformers or OpenAI
  embedding-backed version later if you have network access to a model hub.
- Generation is pluggable: "anthropic", "openai", or "extractive" (a
  no-API-key fallback that returns the most relevant passages directly).
"""

from __future__ import annotations

import os
import glob
from dataclasses import dataclass, field
from typing import List, Tuple

import numpy as np
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity

from pypdf import PdfReader


# ---------------------------------------------------------------------------
# 1. Document Ingestion
# ---------------------------------------------------------------------------
class DocumentLoader:
    """Loads raw text out of PDFs and plain-text files."""

    @staticmethod
    def load_file(path: str) -> str:
        if path.lower().endswith(".pdf"):
            reader = PdfReader(path)
            pages = [page.extract_text() or "" for page in reader.pages]
            return "\n".join(pages)
        with open(path, "r", encoding="utf-8", errors="ignore") as f:
            return f.read()

    @staticmethod
    def load_folder(folder: str, patterns=("*.pdf", "*.txt", "*.md")) -> List[Tuple[str, str]]:
        """Returns a list of (filename, text) for every matching file in folder."""
        docs = []
        for pattern in patterns:
            for path in sorted(glob.glob(os.path.join(folder, pattern))):
                text = DocumentLoader.load_file(path)
                if text.strip():
                    docs.append((os.path.basename(path), text))
        return docs


# ---------------------------------------------------------------------------
# 2. Text Chunking
# ---------------------------------------------------------------------------
class TextChunker:
    """Splits text into overlapping word-based chunks."""

    def __init__(self, chunk_size: int = 200, overlap: int = 40):
        self.chunk_size = chunk_size
        self.overlap = overlap

    def split(self, text: str, source: str = "") -> List["Chunk"]:
        words = text.split()
        chunks = []
        step = max(1, self.chunk_size - self.overlap)
        for start in range(0, len(words), step):
            piece = words[start:start + self.chunk_size]
            if not piece:
                continue
            chunks.append(Chunk(text=" ".join(piece), source=source))
            if start + self.chunk_size >= len(words):
                break
        return chunks


@dataclass
class Chunk:
    text: str
    source: str = ""


# ---------------------------------------------------------------------------
# 3 & 4. Embedding Creation + Vector Database
# ---------------------------------------------------------------------------
class VectorStore:
    """TF-IDF backed vector store with cosine-similarity search."""

    def __init__(self):
        self.vectorizer = TfidfVectorizer(stop_words="english", max_features=8000)
        self.matrix = None
        self.chunks: List[Chunk] = []

    def build(self, chunks: List[Chunk]):
        self.chunks = chunks
        texts = [c.text for c in chunks]
        self.matrix = self.vectorizer.fit_transform(texts)

    # 5 & 6. Query embedding + context retrieval
    def search(self, query: str, top_k: int = 3) -> List[Tuple[Chunk, float]]:
        if self.matrix is None or not self.chunks:
            return []
        query_vec = self.vectorizer.transform([query])
        sims = cosine_similarity(query_vec, self.matrix)[0]
        ranked = np.argsort(sims)[::-1][:top_k]
        return [(self.chunks[i], float(sims[i])) for i in ranked if sims[i] > 0]


# ---------------------------------------------------------------------------
# 7. Answer Generation
# ---------------------------------------------------------------------------
class AnswerGenerator:
    """
    Generates a final answer from retrieved context.

    backend:
      - "extractive": no API key needed, returns the most relevant passages
      - "anthropic":  uses the Anthropic API (needs ANTHROPIC_API_KEY env var)
      - "openai":     uses the OpenAI API (needs OPENAI_API_KEY env var)
    """

    def __init__(self, backend: str = "extractive", model: str = "claude-sonnet-5"):
        self.backend = backend
        self.model = model
        self.client = None
        if backend == "anthropic":
            import anthropic
            self.client = anthropic.Anthropic()
        elif backend == "openai":
            import openai
            self.client = openai.OpenAI()
        elif backend != "extractive":
            raise ValueError(f"Unknown backend: {backend}")

    def generate(self, question: str, retrieved: List[Tuple[Chunk, float]]) -> str:
        if not retrieved:
            return "I couldn't find anything relevant to that question in the document(s)."

        chunks = [c for c, _ in retrieved]

        if self.backend == "extractive":
            return self._extractive_answer(chunks)

        context = "\n\n".join(
            f"[Source: {c.source}]\n{c.text}" for c in chunks
        )
        prompt = (
            "Answer the question using ONLY the context below. "
            "If the answer is not contained in the context, say so explicitly.\n\n"
            f"Context:\n{context}\n\nQuestion: {question}\n\nAnswer:"
        )

        if self.backend == "anthropic":
            resp = self.client.messages.create(
                model=self.model,
                max_tokens=500,
                messages=[{"role": "user", "content": prompt}],
            )
            return resp.content[0].text

        if self.backend == "openai":
            resp = self.client.chat.completions.create(
                model=self.model,
                messages=[{"role": "user", "content": prompt}],
            )
            return resp.choices[0].message.content

    @staticmethod
    def _extractive_answer(chunks: List[Chunk]) -> str:
        parts = [f"(from {c.source})\n{c.text}" for c in chunks]
        return (
            "No LLM backend configured, so here are the most relevant "
            "passages found in the document(s):\n\n" + "\n\n---\n\n".join(parts)
        )


# ---------------------------------------------------------------------------
# Pipeline orchestrator
# ---------------------------------------------------------------------------
@dataclass
class RAGPipeline:
    chunk_size: int = 200
    overlap: int = 40
    top_k: int = 3
    backend: str = "extractive"
    model: str = "claude-sonnet-5"

    chunker: TextChunker = field(init=False)
    store: VectorStore = field(init=False)
    generator: AnswerGenerator = field(init=False)

    def __post_init__(self):
        self.chunker = TextChunker(self.chunk_size, self.overlap)
        self.store = VectorStore()
        self.generator = AnswerGenerator(self.backend, self.model)

    def ingest_folder(self, folder: str):
        docs = DocumentLoader.load_folder(folder)
        if not docs:
            raise FileNotFoundError(f"No .pdf/.txt/.md files found in {folder}")
        all_chunks = []
        for name, text in docs:
            all_chunks.extend(self.chunker.split(text, source=name))
        self.store.build(all_chunks)
        return len(docs), len(all_chunks)

    def ingest_file(self, path: str):
        text = DocumentLoader.load_file(path)
        chunks = self.chunker.split(text, source=os.path.basename(path))
        self.store.build(chunks)
        return len(chunks)

    def ask(self, question: str) -> dict:
        retrieved = self.store.search(question, top_k=self.top_k)
        answer = self.generator.generate(question, retrieved)
        return {
            "question": question,
            "answer": answer,
            "sources": [
                {"source": c.source, "score": round(score, 3), "text": c.text}
                for c, score in retrieved
            ],
        }
