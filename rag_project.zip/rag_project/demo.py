"""
Demo / CLI for the RAG system.

Usage
-----
Ask a single question:
    python demo.py --docs ./documents --question "What is the main idea?"

Interactive mode:
    python demo.py --docs ./documents

Use a real LLM instead of the extractive fallback:
    export ANTHROPIC_API_KEY=sk-...
    python demo.py --docs ./documents --backend anthropic
"""

import argparse
import json

from rag_system import RAGPipeline


def main():
    parser = argparse.ArgumentParser(description="Simple RAG Q&A over your documents")
    parser.add_argument("--docs", required=True, help="Folder containing PDF/TXT/MD files")
    parser.add_argument("--question", help="Ask a single question and exit")
    parser.add_argument("--backend", default="extractive",
                         choices=["extractive", "anthropic", "openai"],
                         help="Answer generation backend")
    parser.add_argument("--model", default="claude-sonnet-5", help="Model name for API backends")
    parser.add_argument("--top_k", type=int, default=3, help="Number of chunks to retrieve")
    parser.add_argument("--chunk_size", type=int, default=200, help="Words per chunk")
    args = parser.parse_args()

    pipeline = RAGPipeline(
        backend=args.backend,
        model=args.model,
        top_k=args.top_k,
        chunk_size=args.chunk_size,
    )

    n_docs, n_chunks = pipeline.ingest_folder(args.docs)
    print(f"Ingested {n_docs} document(s) -> {n_chunks} chunks. Backend: {args.backend}\n")

    if args.question:
        result = pipeline.ask(args.question)
        print_result(result)
        return

    print("Interactive mode. Type a question, or 'quit' to exit.\n")
    while True:
        try:
            question = input("Q: ").strip()
        except (EOFError, KeyboardInterrupt):
            break
        if not question or question.lower() in {"quit", "exit"}:
            break
        result = pipeline.ask(question)
        print_result(result)


def print_result(result: dict):
    print(f"\nQ: {result['question']}")
    print(f"A: {result['answer']}\n")
    print("Retrieved sources:")
    for s in result["sources"]:
        print(f"  - {s['source']} (score={s['score']})")
    print("-" * 60)


if __name__ == "__main__":
    main()
